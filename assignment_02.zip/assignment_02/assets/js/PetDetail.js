document.main.innerHTML += `
    <div id="petName" class="container">
        <h1>${json.pet[getAllUrlParams().index].petName}</h1>
        <p>
            ID: <a href="detail.html?index=${json.pet[getAllUrlParams().index].ID}</a><br />
            Species: <a href="detail.html?index=${json.pet[getAllUrlParams().index].petType}</a><br />
            Breed: <a href="detail.html?index=${json.pet[getAllUrlParams().index].breed}</a><br />
            Fixed: <a href="detail.html?index=${pet[getAllUrlParams().index].spayedNeutered}</a><br />
            Sex: <a href="detail.html?index=${pet[getAllUrlParams().index].Sex}</a><br />
            Age: <a href="detail.html?index=${pet[getAllUrlParams().index].age}</a><br />
            Vaccinated: <a href="detail.html?index=${pet[getAllUrlParams().index].vaccinationStatus}</a><br />
            Location: <a href="detail.html?index=${pet[getAllUrlParams().index].location}</a><br />
            Availble to Adopt: <a href="detail.html?index=${pet[getAllUrlParams().index].available}</a><br />
            Additional Information: <a href="detail.html?index=${pet[getAllUrlParams().index].additionalDetail}</a><br />
        </p>
    </div>`;

async function loadPage() {
    let params = getAllUrlParams(window.location.href);
    let page;
    if (!params.hasOwnProperty('page')) {
        page = 1;
    } else {
        page = params.page;
    }
    console.log(page);
    const response = await fetch('Pets.json');
    const json = await response.json();
    setCurrentPage(page, json);
} 
